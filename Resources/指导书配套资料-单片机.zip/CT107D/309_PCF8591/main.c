#include "tim.h"
#include "seg.h"
#include "stdio.h"
#include "key.h"
#include "iic.h"

unsigned int  uiSeg_Dly;
unsigned char ucState=1, ucSec, ucLed, ucAdc;
unsigned char ucKey_Dly, ucKey_Old;
unsigned char ucSeg_Buf[9], ucSeg_Code[8], ucSeg_Pos;
unsigned long ulms; 

void Key_Proc(void);
void Seg_Proc(void);

void main(void)
{ 
    Cls_Peripheral();
    Timer1Init();	
	
    while(1)
    {
      Key_Proc();
      Seg_Proc();
    }
}

void Time_1(void) interrupt 3
{
  ulms++;
  if(++ucKey_Dly == 10)
    ucKey_Dly = 0;
  if(++uiSeg_Dly == 500)
    uiSeg_Dly = 0;
  if(!(ulms % 1000))
    ucSec++;
  Seg_Disp(ucSeg_Code, ucSeg_Pos);	
  if(++ucSeg_Pos == 8) ucSeg_Pos = 0;
}

void Key_Proc(void)
{
  unsigned char ucKey_Val, ucKey_Down;

  if(ucKey_Dly) return;
  ucKey_Dly = 1;

  ucKey_Val = Key_Read();
  ucKey_Down = ucKey_Val & (ucKey_Old ^ ucKey_Val);
  ucKey_Old = ucKey_Val;

  if(ucKey_Down == 4)
    if(++ucState == 2)
      ucState = 0;

  Led_Disp(ucState+1);
}

void Seg_Proc(void)
{
  if(uiSeg_Dly) return;
  uiSeg_Dly = 1;
	
  switch(ucState)
  {
    case 0:
      sprintf(ucSeg_Buf, "1 %06u", (unsigned int)ucSec);
      break;
    case 1:
      ucAdc = PCF8591_Adc();
      PCF8591_Dac(ucAdc);
      sprintf(ucSeg_Buf, "2    %03u", (unsigned int)ucAdc);
  }
  Seg_Tran(ucSeg_Buf, ucSeg_Code);
}
