#ifndef __ONEWIRE_H
#define __ONEWIRE_H

unsigned int rd_temperature(void);
#endif
