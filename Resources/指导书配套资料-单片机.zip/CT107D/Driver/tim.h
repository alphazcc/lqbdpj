#ifndef __TIM_H
#define __TIM_H
#include "STC15F2K60S2.H"

void Cls_Peripheral(void);
void Led_Disp(unsigned char ucLed);
void Timer1Init(void);
#endif
