#ifndef __Ultrasonic_H_
#define __Ultrasonic_H_
#include "STC15F2K60S2.H"

void Timer0Init(void);
unsigned char Wave_Recv(void);
#endif